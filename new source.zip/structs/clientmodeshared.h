#pragma once
class CClientModeShared{};