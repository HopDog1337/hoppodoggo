typedef void(__cdecl *MsgFn)(char const* pMsg, va_list);
extern void __cdecl Msg(char const* msg, ...);